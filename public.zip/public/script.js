document.addEventListener('DOMContentLoaded', () => {
    // --- State Management ---
    let allWorks = [];
    let currentLang = localStorage.getItem('lang') || 'en';
    let isAdminMode = false;

    // --- DOM Elements ---
    const themeToggle = document.getElementById('theme-toggle');
    const langToggle = document.getElementById('lang-toggle');
    const workGrid = document.getElementById('work-grid');
    const filterButtons = document.querySelectorAll('.work-filters .filter-btn');
    const lightbox = document.getElementById('lightbox');
    const lightboxBody = document.getElementById('lightbox-body');
    const lightboxClose = lightbox.querySelector('.lightbox-close');
    const adminPanel = document.getElementById('admin-panel');
    const saveChangesBtn = document.getElementById('save-changes-btn');

    // --- INITIALIZATION ---
    const init = () => {
        setupEventListeners();
        loadTheme();
        loadLanguage();
        fetchWorksAndRender();
        initSmoothScroll();
        showFloatingButtons();
    };

    // --- EVENT LISTENERS ---
    const setupEventListeners = () => {
        themeToggle.addEventListener('click', toggleTheme);
        langToggle.addEventListener('click', toggleLanguage);
        filterButtons.forEach(button => button.addEventListener('click', handleFilterClick));
        workGrid.addEventListener('click', handleWorkItemClick);
        lightboxClose.addEventListener('click', closeLightbox);
        lightbox.addEventListener('click', (e) => e.target === lightbox && closeLightbox());
        document.addEventListener('keydown', handleGlobalKeyDown);
        saveChangesBtn.addEventListener('click', saveChanges);
    };

    // --- DATA FETCHING & RENDERING ---
    const fetchWorksAndRender = async () => {
        try {
            const response = await fetch('/api/works');
            if (!response.ok) throw new Error('Network response was not ok');
            allWorks = await response.json();
            renderWorkGrid(allWorks);
        } catch (error) {
            console.error('Failed to fetch works:', error);
            workGrid.innerHTML = '<p>Error loading portfolio items. Please try again later.</p>';
        }
    };

    const renderWorkGrid = (items) => {
        workGrid.innerHTML = '';
        items.forEach((item, index) => {
            const workItem = document.createElement('div');
            workItem.className = `work-item ${item.category}`;
            workItem.dataset.index = index;

            let content = '';
            const title = item[`title_${currentLang}`] || item.title_en;

            if (item.category === 'photo' || item.category === 'video') {
                content = `
                    <img src="${item.thumbnail}" alt="${title}">
                    <div class="work-overlay">
                        <i class="fas fa-${item.category === 'photo' ? 'camera' : 'play'}"></i>
                        <h4>${title}</h4>
                    </div>
                `;
            } else if (item.category === 'writing') {
                content = `
                    <div class="work-writing-thumb">
                        <i class="fas fa-file-alt"></i>
                        <h4>${title}</h4>
                    </div>
                `;
            }
            workItem.innerHTML = content;
            workGrid.appendChild(workItem);
        });
    };

    // --- THEME & LANGUAGE ---
    const loadTheme = () => {
        if (localStorage.getItem('theme') === 'dark') {
            document.body.classList.add('dark-mode');
            themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
        }
    };

    const toggleTheme = () => {
        document.body.classList.toggle('dark-mode');
        if (document.body.classList.contains('dark-mode')) {
            localStorage.setItem('theme', 'dark');
            themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
        } else {
            localStorage.removeItem('theme');
            themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
        }
    };

    const loadLanguage = () => {
        document.querySelectorAll('[data-en]').forEach(el => {
            el.innerHTML = el.dataset[currentLang] || el.dataset.en;
        });
        document.documentElement.lang = currentLang;
        langToggle.textContent = currentLang === 'en' ? 'BN' : 'EN';
        renderWorkGrid(getFilteredItems()); // Re-render works with new language
    };

    const toggleLanguage = () => {
        currentLang = currentLang === 'en' ? 'bn' : 'en';
        localStorage.setItem('lang', currentLang);
        loadLanguage();
    };

    // --- WORKS FILTERING & LIGHTBOX ---
    const handleFilterClick = (e) => {
        const filter = e.currentTarget.dataset.filter;
        filterButtons.forEach(btn => btn.classList.remove('active'));
        e.currentTarget.classList.add('active');
        renderWorkGrid(getFilteredItems(filter));
    };

    const getFilteredItems = (filter = 'all') => {
        if (filter === 'all') {
            const activeFilterBtn = document.querySelector('.filter-btn.active');
            filter = activeFilterBtn ? activeFilterBtn.dataset.filter : 'all';
        }
        if (filter === 'all') return allWorks;
        return allWorks.filter(item => item.category === filter);
    };

    const handleWorkItemClick = (e) => {
        const itemElement = e.target.closest('.work-item');
        if (itemElement) {
            const index = parseInt(itemElement.dataset.index, 10);
            openLightbox(allWorks[index], index);
        }
    };

    const openLightbox = (item, index) => {
        let content = '';
        const title_en = item.title_en;
        const title_bn = item.title_bn;
        const currentTitle = item[`title_${currentLang}`] || title_en;

        if (item.category === 'photo') {
            content = `<img src="${item.fullSource}" alt="${currentTitle}">`;
        } else if (item.category === 'video') {
            content = `<div class="video-iframe-wrapper"><iframe src="${item.fullSource}?autoplay=1" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>`;
        } else if (item.category === 'writing') {
            const writingContent = item[`content_${currentLang}`] || item.content_en;
            content = `<div class="writing-content-full">${writingContent}</div>`;
        }

        lightboxBody.innerHTML = content;

        if (isAdminMode) {
            const editArea = document.createElement('div');
            editArea.className = 'lightbox-admin-edit-area';
            let editFields = `<h4>Admin Edit</h4>`;
            editFields += `
                <label for="title_en">Title (EN)</label>
                <input type="text" id="edit-title_en" value="${title_en}">
                <label for="title_bn">Title (BN)</label>
                <input type="text" id="edit-title_bn" value="${title_bn}">
            `;

            if (item.category === 'photo' || item.category === 'video') {
                editFields += `
                    <label for="thumbnail">Thumbnail URL</label>
                    <input type="text" id="edit-thumbnail" value="${item.thumbnail}">
                    <label for="fullSource">Full Image/Video URL</label>
                    <input type="text" id="edit-fullSource" value="${item.fullSource}">
                `;
            } else if (item.category === 'writing') {
                lightboxBody.querySelector('.writing-content-full').setAttribute('contenteditable', true);
            }
            
            editArea.innerHTML = editFields;
            lightboxBody.appendChild(editArea);
            lightboxBody.dataset.index = index;
        }

        lightbox.classList.add('show');
        document.body.style.overflow = 'hidden';
    };
    
    const closeLightbox = () => {
        if(isAdminMode && lightboxBody.dataset.index) {
            updateItemFromLightbox();
        }
        lightbox.classList.remove('show');
        lightboxBody.innerHTML = '';
        document.body.style.overflow = '';
    };

    // --- ADMIN MODE ---
    const handleGlobalKeyDown = (e) => {
        if (e.ctrlKey && e.key.toLowerCase() === 'x') {
            e.preventDefault();
            if (!isAdminMode) {
                const password = prompt('Enter admin password:');
                if (password === 'Sheikhraselrobin713206') {
                    enableAdminMode();
                } else if(password) {
                    alert('Incorrect password.');
                }
            }
        }
    };
    
    const enableAdminMode = () => {
        isAdminMode = true;
        adminPanel.classList.add('show');
        alert('Admin mode activated. You can now click on "My Works" items to edit them.');
    };

    const updateItemFromLightbox = () => {
        const index = parseInt(lightboxBody.dataset.index, 10);
        if (isNaN(index)) return;

        const item = allWorks[index];
        item.title_en = document.getElementById('edit-title_en').value;
        item.title_bn = document.getElementById('edit-title_bn').value;

        if (item.category === 'photo' || item.category === 'video') {
            item.thumbnail = document.getElementById('edit-thumbnail').value;
            item.fullSource = document.getElementById('edit-fullSource').value;
        } else if (item.category === 'writing') {
            const editedContent = lightboxBody.querySelector('[contenteditable]').innerHTML;
            // A simple heuristic to decide which language was edited
            if (currentLang === 'bn') {
                 item.content_bn = editedContent;
            } else {
                 item.content_en = editedContent;
            }
        }
        
        // Re-render the grid to show immediate changes
        renderWorkGrid(getFilteredItems());
    };
    
    const saveChanges = async () => {
        if (!isAdminMode) return;
        
        try {
            const response = await fetch('/api/works', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(allWorks)
            });
            
            if(!response.ok) throw new Error('Failed to save changes.');

            const result = await response.json();
            alert(result.message);

        } catch (error) {
            console.error('Error saving changes:', error);
            alert('Could not save changes to the server.');
        }
    };

    // --- OTHER UTILITIES ---
    const initSmoothScroll = () => {
        document.querySelectorAll('.navigation a').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const targetId = this.getAttribute('href');
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80, // Adjust for fixed headers/panels
                        behavior: 'smooth'
                    });
                }
            });
        });
    };

    const showFloatingButtons = () => {
        setTimeout(() => {
            document.querySelectorAll('.floating-btn').forEach(btn => btn.classList.add('show'));
        }, 3000);
    };

    // --- START THE APP ---
    init();
});